# Learning Meteor Application Development
by Isaac Strack

This is the code base for the Packt Publishing Learning Meteor Application Development video series, found here:
http://bit.ly/packmeteorvideo
