// general server-side code
// (will get specific as needed)
console.log ("we can log to the server console!");